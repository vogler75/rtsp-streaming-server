// Copyright 2022 Siemens AG. This file is subject to the terms and conditions of the MIT License. See LICENSE file in the top-level directory.
//
// SPDX-License-Identifier: MIT

////////////////////////////////////////////
// VideoPlayer internal properties

let websocket = null;
let videoElement = null;
let statusElement = null;
let versionElement = null;
let isConnected = false;
let currentURL = '';
let currentToken = '';
let shouldConnect = false;
let reconnectTimer = null;
let reconnectAttempts = 0;
let reconnectInterval = 3000;

// FPS and bitrate tracking variables
let frameCount = 0;
let fpsCounter = 0;
let lastFpsTime = Date.now();
let bytesReceived = 0;
let lastBitrateTime = Date.now();

// Control mode variables
let isControlMode = false;
let controlWebSocket = null;
let currentPlayFrom = '';
let currentPlayTo = '';
let currentPlay = false;
let currentSpeed = 1.0;
let currentLive = false;
let currentRecordingReason = '';
let currentRecordingActive = false;
let currentGoto = '';

////////////////////////////////////////////
// VideoPlayer functions

function initializeVideoPlayer() {
  videoElement = document.getElementById('videoPlayer');
  statusElement = document.getElementById('status');
  versionElement = document.getElementById('versionDisplay');
  
  videoElement.onerror = function(e) {
    // Only log video errors if we're actually using the video element
    if (videoElement.style.display !== 'none') {
      console.error('Video error:', e);
      updateConnectionStatus(false);
    }
  };
  
  videoElement.onloadstart = function() {
    if (videoElement.style.display !== 'none') {
      console.log('Video loading started');
    }
  };
  
  videoElement.oncanplay = function() {
    if (videoElement.style.display !== 'none') {
      console.log('Video can start playing');
    }
  };
}

function updateConnectionStatus(connected) {
  isConnected = connected;
  WebCC.Properties.connected = connected;
  
  // Reset statistics when disconnected
  if (!connected) {
    frameCount = 0;
    fpsCounter = 0;
    lastFpsTime = Date.now();
    bytesReceived = 0;
    lastBitrateTime = Date.now();
    WebCC.Properties.fps = 0;
    WebCC.Properties.kbs = 0;
  }
  
  if (statusElement) {
    if (connected) {
      // Hide status when connected
      statusElement.style.display = 'none';
      reconnectAttempts = 0;
    } else if (shouldConnect) {
      // Show status when disconnected but trying to connect
      statusElement.style.display = 'block';
      const reconnectText = reconnectAttempts > 0 ? ` (Retry ${reconnectAttempts})` : '';
      statusElement.textContent = 'Disconnected' + reconnectText;
      statusElement.style.backgroundColor = 'rgba(128,0,0,0.7)';
    } else {
      // Show status when stopped
      statusElement.style.display = 'block';
      statusElement.textContent = 'Stopped';
      statusElement.style.backgroundColor = 'rgba(64,64,64,0.7)';
    }
  }
  
  console.log('Connection status:', connected);
}

function scheduleReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
  }
  
  // Only reconnect if shouldConnect is true (endless reconnection)
  if (shouldConnect && currentURL) {
    reconnectAttempts++;
    console.log(`Scheduling reconnect attempt ${reconnectAttempts} in ${reconnectInterval}ms`);
    updateConnectionStatus(false);
    
    reconnectTimer = setTimeout(() => {
      if (shouldConnect) { // Check again in case it changed during timeout
        console.log(`Attempting to reconnect (${reconnectAttempts})`);
        connectToWebSocket(currentURL);
      }
    }, reconnectInterval);
  } else {
    console.log('Not reconnecting: shouldConnect =', shouldConnect, 'currentURL =', currentURL);
  }
}

function showBlankScreen() {
  // Hide video/image elements
  videoElement.style.display = 'none';
  const imgElement = document.getElementById('mjpegFrame');
  if (imgElement) {
    imgElement.style.display = 'none';
    // Clean up any blob URL
    if (imgElement.src && imgElement.src.startsWith('blob:')) {
      URL.revokeObjectURL(imgElement.src);
    }
  }
}

function connectToWebSocket(url) {
  if (!url || url.trim() === '' || !shouldConnect) {
    console.log('No URL provided or connection disabled');
    updateConnectionStatus(false);
    return;
  }
  
  // Check if we're in control mode and need to connect to control endpoint
  if (isControlMode) {
    connectToControlWebSocket(url);
    return;
  }
  
  if (websocket) {
    websocket.close();
    websocket = null;
  }
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  
  try {
    console.log('Attempting WebSocket connection...');
    console.log('URL:', url);
    console.log('Protocol:', url.startsWith('wss://') ? 'Secure WebSocket (WSS)' : 'WebSocket (WS)');
    
    // Add token to URL if provided
    let connectUrl = url;
    if (currentToken && currentToken.trim() !== '') {
      const separator = url.includes('?') ? '&' : '?';
      connectUrl = url + separator + 'token=' + encodeURIComponent(currentToken);
      console.log('Using authentication token');
    }
    
    // For WSS with self-signed certificates, try different approaches
    if (connectUrl.startsWith('wss://')) {
      console.log('Attempting WSS connection (ignoring certificate errors where possible)');
      
      // Try to create WebSocket with additional error handling for certificate issues
      try {
        websocket = new WebSocket(connectUrl);
      } catch (certError) {
        console.warn('WSS connection failed, possibly due to certificate issues:', certError);
        
        // Fallback: try converting WSS to WS for testing
        const wsUrl = connectUrl.replace('wss://', 'ws://');
        console.log('Attempting fallback to WS:', wsUrl);
        websocket = new WebSocket(wsUrl);
      }
    } else {
      websocket = new WebSocket(connectUrl);
    }
    
    websocket.onopen = function() {
      console.log('WebSocket connected');
      updateConnectionStatus(true);
    };
    
    websocket.onmessage = function(event) {
      if (event.data instanceof Blob) {
        // Check if this is an empty frame (ping) - same as server HTML
        if (event.data.size === 0) {
          return;
        }
        
        // Handle MJPEG frame from WebSocket
        // Create or update an img element to display the MJPEG frame
        let imgElement = document.getElementById('mjpegFrame');
        if (!imgElement) {
          imgElement = document.createElement('img');
          imgElement.id = 'mjpegFrame';
          imgElement.style.width = '100%';
          imgElement.style.height = '100%';
          imgElement.style.objectFit = 'contain';
          
          // Replace video element with img element
          videoElement.style.display = 'none';
          videoElement.parentNode.insertBefore(imgElement, videoElement.nextSibling);
        } else {
          // Make sure img element is visible (might have been hidden by showBlankScreen)
          imgElement.style.display = 'block';
          videoElement.style.display = 'none';
        }
        
        // Create blob URL and clean up previous one
        const previousSrc = imgElement.src;
        if (previousSrc && previousSrc.startsWith('blob:')) {
          URL.revokeObjectURL(previousSrc);
        }
        
        // Set new blob URL
        const blobUrl = URL.createObjectURL(event.data);
        imgElement.src = blobUrl;
        
        // Update statistics
        frameCount++;
        fpsCounter++;
        bytesReceived += event.data.size;
        
        const now = Date.now();
        
        // FPS calculation - update every second
        if (now - lastFpsTime >= 1000) {
          const fps = Math.round(fpsCounter * 1000 / (now - lastFpsTime));
          WebCC.Properties.fps = fps;
          fpsCounter = 0;
          lastFpsTime = now;
        }
        
        // Bitrate calculation - update every second
        if (now - lastBitrateTime >= 1000) {
          const kbs = Math.round(bytesReceived / 1024); // KB/s
          WebCC.Properties.kbs = kbs;
          bytesReceived = 0;
          lastBitrateTime = now;
        }
        
        // Clean up blob URL after image loads
        imgElement.onload = function() {
          // Small delay before cleanup to ensure image is displayed
          setTimeout(() => {
            URL.revokeObjectURL(blobUrl);
          }, 100);
        };
        
      } else if (typeof event.data === 'string') {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'stream_url' && data.url) {
            // Handle video URL (show video element, hide img)
            videoElement.style.display = 'block';
            videoElement.src = data.url;
            
            const imgElement = document.getElementById('mjpegFrame');
            if (imgElement) {
              imgElement.style.display = 'none';
              // Clean up any remaining blob URL
              if (imgElement.src && imgElement.src.startsWith('blob:')) {
                URL.revokeObjectURL(imgElement.src);
              }
            }
          }
        } catch (e) {
          console.log('Received text data:', event.data);
        }
      }
    };
    
    websocket.onerror = function(error) {
      console.error('WebSocket error occurred');
      console.error('URL:', currentURL);
      console.error('ReadyState:', websocket ? websocket.readyState : 'null');
      console.error('Error event:', error);
      
      // Provide specific guidance for WSS certificate issues
      if (currentURL.startsWith('wss://')) {
        console.error('====== WSS CONNECTION TROUBLESHOOTING ======');
        console.error('If this is a self-signed certificate error:');
        console.error('1. Open the server URL in a browser: ' + currentURL.replace('wss://', 'https://'));
        console.error('2. Accept the security warning to trust the certificate');
        console.error('3. Or disable TLS in server config.toml and use ws:// instead');
        console.error('4. Or add the certificate to the system trust store');
        console.error('============================================');
      }
      
      updateConnectionStatus(false);
      scheduleReconnect();
    };
    
    websocket.onclose = function(event) {
      console.log('WebSocket closed');
      console.log('Code:', event.code);
      console.log('Reason:', event.reason || 'No reason provided');
      console.log('Was clean:', event.wasClean);
      console.log('URL was:', currentURL);
      
      // Common WebSocket close codes
      const closeReasons = {
        1000: 'Normal Closure',
        1001: 'Going Away',
        1002: 'Protocol Error',
        1003: 'Unsupported Data',
        1006: 'Abnormal Closure',
        1007: 'Invalid frame payload data',
        1008: 'Policy Violation',
        1009: 'Message too big',
        1010: 'Missing Extension',
        1011: 'Internal Error',
        1015: 'TLS Handshake'
      };
      
      const closeDescription = closeReasons[event.code] || 'Unknown';
      console.log('Close description:', closeDescription);
      
      updateConnectionStatus(false);
      websocket = null;
      
      if (event.code !== 1000) {
        scheduleReconnect();
      }
    };
    
  } catch (error) {
    console.error('Failed to create WebSocket:', error);
    updateConnectionStatus(false);
    scheduleReconnect();
  }
}

function connectToControlWebSocket(url) {
  console.log('[CWC DEBUG] 🔗 Connecting to control WebSocket...');
  
  if (controlWebSocket) {
    console.log('[CWC DEBUG] Closing existing control WebSocket');
    controlWebSocket.close();
    controlWebSocket = null;
  }
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  
  try {
    // Convert the URL to control endpoint (add /control to the path)
    let controlUrl = url;
    if (controlUrl.includes('?')) {
      // Insert /control before query parameters
      controlUrl = controlUrl.replace('?', '/control?');
    } else {
      controlUrl = controlUrl + '/control';
    }
    
    // Only add token if provided - no other parameters
    if (currentToken && currentToken.trim() !== '') {
      const separator = controlUrl.includes('?') ? '&' : '?';
      controlUrl += separator + 'token=' + encodeURIComponent(currentToken);
      console.log('[CWC DEBUG] Adding token to control URL');
    }
    
    console.log('[CWC DEBUG] 🔗 Control URL:', controlUrl);
    controlWebSocket = new WebSocket(controlUrl);
    
    controlWebSocket.onopen = function() {
      console.log('[CWC DEBUG] ✅ Control WebSocket connected successfully');
      updateConnectionStatus(true);
      
      // Auto-enable live mode when connection is established
      console.log('[CWC DEBUG] 📺 Auto-enabling live mode after connection established');
      
      // Update internal state and WebCC properties
      currentLive = true;
      currentPlay = false;
      WebCC.Properties.live = true;
      WebCC.Properties.play = false;
      
      // Send live command to start streaming
      sendControlCommand({ cmd: 'live' });
    };
    
    controlWebSocket.onmessage = function(event) {
      if (event.data instanceof Blob) {
        // Handle binary messages from control WebSocket
        if (event.data.size === 0) {
          return; // Skip empty frames
        }
        
        // Read the binary data to check protocol byte
        event.data.arrayBuffer().then(buffer => {
          const dataView = new DataView(buffer);
          
          if (buffer.byteLength < 9) {
            console.warn('Control message too short, expected at least 9 bytes');
            return;
          }
          
          // First byte indicates message type
          const messageType = dataView.getUint8(0);
          
          if (messageType === 0) {
            // Video frame message
            // Next 8 bytes are timestamp (little-endian 64-bit integer)
            const timestampMs = dataView.getBigInt64(1, true); // little-endian
            const frameData = buffer.slice(9); // Rest is frame data
            
            // Update the timestamp property with the current frame timestamp in ISO format
            const timestampNumber = Number(timestampMs);
            const timestampISO = new Date(timestampNumber).toISOString();
            WebCC.Properties.timestamp = timestampISO;
            
            // Video frame received and timestamp property updated (removed verbose logging)
            
            // Create or update an img element to display the frame
            let imgElement = document.getElementById('mjpegFrame');
            if (!imgElement) {
              imgElement = document.createElement('img');
              imgElement.id = 'mjpegFrame';
              imgElement.style.width = '100%';
              imgElement.style.height = '100%';
              imgElement.style.objectFit = 'contain';
              
              videoElement.style.display = 'none';
              videoElement.parentNode.insertBefore(imgElement, videoElement.nextSibling);
            } else {
              imgElement.style.display = 'block';
              videoElement.style.display = 'none';
            }
            
            // Create blob URL and clean up previous one
            const previousSrc = imgElement.src;
            if (previousSrc && previousSrc.startsWith('blob:')) {
              URL.revokeObjectURL(previousSrc);
            }
            
            const frameBlob = new Blob([frameData], { type: 'image/jpeg' });
            const blobUrl = URL.createObjectURL(frameBlob);
            imgElement.src = blobUrl;
            
            // Update statistics
            frameCount++;
            fpsCounter++;
            bytesReceived += event.data.size;
            
            const now = Date.now();
            
            // FPS calculation
            if (now - lastFpsTime >= 1000) {
              const fps = Math.round(fpsCounter * 1000 / (now - lastFpsTime));
              WebCC.Properties.fps = fps;
              fpsCounter = 0;
              lastFpsTime = now;
            }
            
            // Bitrate calculation
            if (now - lastBitrateTime >= 1000) {
              const kbs = Math.round(bytesReceived / 1024);
              WebCC.Properties.kbs = kbs;
              bytesReceived = 0;
              lastBitrateTime = now;
            }
            
            // Clean up blob URL after image loads
            imgElement.onload = function() {
              setTimeout(() => {
                URL.revokeObjectURL(blobUrl);
              }, 100);
            };
            
          } else if (messageType === 1) {
            // JSON response message
            const jsonData = buffer.slice(1); // Skip first byte
            const jsonString = new TextDecoder().decode(jsonData);
            
            try {
              const response = JSON.parse(jsonString);
              console.log('[CWC DEBUG] ⬅ RECEIVED JSON RESPONSE:', response);
              
              // Handle command responses
              if (response.code) {
                if (response.code === 200) {
                  console.log('[CWC DEBUG] ✅ Control command successful:', response.text);
                  if (response.data) {
                    console.log('[CWC DEBUG] Response data:', response.data);
                  }
                } else {
                  console.error('[CWC DEBUG] ❌ Control command failed:', response.text, 'Code:', response.code);
                }
              }
            } catch (e) {
              console.error('[CWC DEBUG] ⬅ Failed to parse JSON response:', e);
              console.log('[CWC DEBUG] Raw JSON data:', jsonString);
            }
          } else {
            console.warn('[CWC DEBUG] ⬅ UNKNOWN MESSAGE TYPE:', messageType, 'Buffer size:', buffer.byteLength);
          }
        }).catch(error => {
          console.error('[CWC DEBUG] ⬅ Error reading binary data:', error);
        });
        
      } else if (typeof event.data === 'string') {
        // Handle text messages (fallback)
        try {
          const response = JSON.parse(event.data);
          console.log('[CWC DEBUG] ⬅ RECEIVED TEXT RESPONSE:', response);
          
          // Handle command responses
          if (response.code) {
            if (response.code === 200) {
              console.log('[CWC DEBUG] ✅ Control command successful (text):', response.text);
            } else {
              console.error('[CWC DEBUG] ❌ Control command failed (text):', response.text);
            }
          }
        } catch (e) {
          console.log('[CWC DEBUG] ⬅ RECEIVED TEXT MESSAGE (non-JSON):', event.data);
        }
      }
    };
    
    controlWebSocket.onerror = function(error) {
      console.error('[CWC DEBUG] ❌ Control WebSocket error:', error);
      updateConnectionStatus(false);
      scheduleReconnect();
    };
    
    controlWebSocket.onclose = function(event) {
      console.log('[CWC DEBUG] 🔌 Control WebSocket closed:', event.code, event.reason || 'No reason provided');
      updateConnectionStatus(false);
      controlWebSocket = null;
      
      if (event.code !== 1000) {
        console.log('[CWC DEBUG] Scheduling reconnect due to abnormal close');
        scheduleReconnect();
      }
    };
    
  } catch (error) {
    console.error('[CWC DEBUG] ❌ Failed to create control WebSocket:', error);
    updateConnectionStatus(false);
    scheduleReconnect();
  }
}

function sendControlCommand(command) {
  if (!controlWebSocket) return;
  
  if (controlWebSocket.readyState !== WebSocket.OPEN) {
    console.error('[CWC DEBUG] Control WebSocket not connected - cannot send command:', command);
    return;
  }
  
  const commandStr = JSON.stringify(command);
  console.log('[CWC DEBUG] ➤ SENDING CONTROL COMMAND:', commandStr);
  controlWebSocket.send(commandStr);
}

function handleRecordingControl(active, reason) {
  if (!isControlMode || !currentURL) {
    console.log('[CWC DEBUG] Recording control only available in control mode');
    return;
  }
  
  // Use HTTP API for recording control
  // Convert WebSocket URL to HTTP URL and preserve the camera path
  let baseUrl = currentURL.replace(/^ws(s?):\/\//, 'http$1://');
  
  // Remove /control from the end if it exists (from control WebSocket URL)
  baseUrl = baseUrl.replace(/\/control(\?.*)?$/, '');
  
  const endpoint = active ? '/control/recording/start' : '/control/recording/stop';
  const fullUrl = baseUrl + endpoint;
  
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  
  if (currentToken) {
    requestOptions.headers['Authorization'] = 'Bearer ' + currentToken;
    console.log('[CWC DEBUG] Using token authentication for HTTP request');
  }
  
  if (active) {
    // Always pass reason when starting recording, use empty string if no reason provided
    requestOptions.body = JSON.stringify({ reason: reason || '' });
  }
  
  console.log('[CWC DEBUG] ➤ SENDING HTTP REQUEST:', {
    method: 'POST',
    url: fullUrl,
    body: requestOptions.body || '(no body)',
    headers: requestOptions.headers
  });
  
  fetch(fullUrl, requestOptions)
    .then(response => {
      console.log('[CWC DEBUG] ⬅ HTTP RESPONSE STATUS:', response.status, response.statusText);
      return response.json();
    })
    .then(data => {
      console.log('[CWC DEBUG] ⬅ HTTP RESPONSE DATA:', data);
    })
    .catch(error => {
      console.error('[CWC DEBUG] ⬅ HTTP REQUEST ERROR:', error);
    });
}

function setProperty(data) {  
  switch (data.key) {
    case 'URL':
      if (data.value !== currentURL) {
        const oldURL = currentURL;
        currentURL = data.value;
        reconnectAttempts = 0;
        
        // If we're connected or trying to connect, disconnect first then reconnect
        if (shouldConnect) {
          // Disconnect from old URL if connected
          if (websocket) {
            console.log('URL changed from', oldURL, 'to', currentURL, '- reconnecting...');
            websocket.close();
            websocket = null;
          }
          
          // Clear any pending reconnection timers
          if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
          }
          
          // Connect to new URL
          if (currentURL) {
            connectToWebSocket(currentURL);
          } else {
            // No URL provided, just update status
            updateConnectionStatus(false);
            showBlankScreen();
          }
        }
      }
      break;
    case 'connect':
      shouldConnect = data.value;
      if (shouldConnect) {
        // Start connecting
        reconnectAttempts = 0;
        if (currentURL) {
          connectToWebSocket(currentURL);
          
          // Live mode will be auto-enabled after connection is established
        }
      } else {
        // Disconnect and show blank screen
        if (websocket) {
          websocket.close();
          websocket = null;
        }
        if (controlWebSocket) {
          controlWebSocket.close();
          controlWebSocket = null;
        }
        if (reconnectTimer) {
          clearTimeout(reconnectTimer);
          reconnectTimer = null;
        }
        updateConnectionStatus(false);
        showBlankScreen();
      }
      break;
    case 'version':
      if (versionElement) {
        versionElement.style.display = data.value ? 'block' : 'none';
      }
      break;
    case 'token':
      if (data.value !== currentToken) {
        currentToken = data.value;
        console.log('Token updated');
        
        // If we're connected and token changed, reconnect with new token
        if (shouldConnect && currentURL) {
          if (websocket) {
            console.log('Token changed - reconnecting with new authentication...');
            websocket.close();
            websocket = null;
          }
          
          // Clear any pending reconnection timers
          if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
          }
          
          // Reconnect with new token
          connectToWebSocket(currentURL);
        }
      }
      break;
    case 'control':
      isControlMode = data.value;
      console.log('[CWC DEBUG] 🔧 Control mode changed to:', isControlMode);
      
      // Reconnect if URL is available and we're supposed to be connected
      if (shouldConnect && currentURL) {
        console.log('[CWC DEBUG] Reconnecting due to control mode change...');
        if (websocket) {
          websocket.close();
          websocket = null;
        }
        if (controlWebSocket) {
          controlWebSocket.close();
          controlWebSocket = null;
        }
        connectToWebSocket(currentURL);
      }
      break;
    case 'play_from':
      currentPlayFrom = data.value;
      console.log('[CWC DEBUG] 🔧 Play from timestamp changed to:', currentPlayFrom);
      break;
    case 'play_to':
      currentPlayTo = data.value;
      console.log('[CWC DEBUG] 🔧 Play to timestamp changed to:', currentPlayTo);
      break;
    case 'play':
      currentPlay = data.value;
      console.log('[CWC DEBUG] 🔧 Play control changed to:', currentPlay);
      
      if (isControlMode && controlWebSocket) {
        if (currentPlay) {
          // Start playback
          const command = {
            cmd: 'start',
            from: currentPlayFrom
          };
          if (currentPlayTo) {
            command.to = currentPlayTo;
          }
          console.log('[CWC DEBUG] 🎬 Triggering playback start with timestamps from:', currentPlayFrom, 'to:', currentPlayTo || '(end)');
          sendControlCommand(command);
        } else {
          // Stop playback
          console.log('[CWC DEBUG] ⏹️ Triggering playback stop');
          sendControlCommand({ cmd: 'stop' });
        }
      } else {
        console.log('[CWC DEBUG] ⚠️ Play command ignored - not in control mode or WebSocket not connected');
      }
      break;
    case 'speed':
      currentSpeed = data.value;
      console.log('[CWC DEBUG] 🔧 Playback speed changed to:', currentSpeed);
      
      if (isControlMode && controlWebSocket) {
        console.log('[CWC DEBUG] ⚡ Triggering speed change');
        sendControlCommand({
          cmd: 'speed',
          speed: currentSpeed
        });
      } else {
        console.log('[CWC DEBUG] ⚠️ Speed command ignored - not in control mode or WebSocket not connected');
      }
      break;
    case 'live':
      currentLive = data.value;
      console.log('[CWC DEBUG] 🔧 Live stream control changed to:', currentLive);
      
      if (isControlMode && controlWebSocket) {
        if (currentLive) {
          console.log('[CWC DEBUG] 📺 Triggering live stream start');
          sendControlCommand({ cmd: 'live' });
        } else {
          console.log('[CWC DEBUG] ⏹️ Triggering live stream stop');
          sendControlCommand({ cmd: 'stop' });
        }
      } else {
        console.log('[CWC DEBUG] ⚠️ Live command ignored - not in control mode or WebSocket not connected');
      }
      break;
    case 'recording_reason':
      currentRecordingReason = data.value;
      console.log('[CWC DEBUG] 🔧 Recording reason changed to:', currentRecordingReason);
      break;
    case 'recording_active':
      currentRecordingActive = data.value;
      console.log('[CWC DEBUG] 🔧 Recording active changed to:', currentRecordingActive);
      
      if (isControlMode) {
        console.log('[CWC DEBUG] 🔴 Triggering recording control - active:', currentRecordingActive, 'reason:', currentRecordingReason);
        handleRecordingControl(currentRecordingActive, currentRecordingReason);
      } else {
        console.log('[CWC DEBUG] ⚠️ Recording command ignored - not in control mode');
      }
      break;
    case 'goto':
      currentGoto = data.value;
      console.log('[CWC DEBUG] 🔧 Goto timestamp changed to:', currentGoto);
      
      if (isControlMode && controlWebSocket && currentGoto) {
        console.log('[CWC DEBUG] 🎯 Triggering goto command to timestamp:', currentGoto);
        sendControlCommand({
          cmd: 'goto',
          timestamp: currentGoto
        });
      } else if (!currentGoto) {
        console.log('[CWC DEBUG] ⚠️ Goto command ignored - empty timestamp');
      } else {
        console.log('[CWC DEBUG] ⚠️ Goto command ignored - not in control mode or WebSocket not connected');
      }
      break;
  }
}

////////////////////////////////////////////
// Initialize the custom control
WebCC.start(
  function (result) {
    if (result) {
      console.log('WebCC connected successfully');
      initializeVideoPlayer();
      
      // Set initial properties
      currentURL = WebCC.Properties.URL || '';
      currentToken = WebCC.Properties.token || '';
      shouldConnect = WebCC.Properties.connect || false;
      isControlMode = WebCC.Properties.control || false;
      currentPlayFrom = WebCC.Properties.play_from || '';
      currentPlayTo = WebCC.Properties.play_to || '';
      currentPlay = WebCC.Properties.play || false;
      currentSpeed = WebCC.Properties.speed || 1.0;
      currentLive = WebCC.Properties.live || false;
      currentRecordingReason = WebCC.Properties.recording_reason || '';
      currentRecordingActive = WebCC.Properties.recording_active || false;
      currentGoto = WebCC.Properties.goto || '';
      
      // Check version property at startup
      if (versionElement && WebCC.Properties.version) {
        versionElement.style.display = 'block';
      }
      
      // Connect if both URL and connect are set
      if (shouldConnect && currentURL) {
        connectToWebSocket(currentURL);
      } else {
        showBlankScreen();
        updateConnectionStatus(false);
      }
      
      // Subscribe for property changes
      WebCC.onPropertyChanged.subscribe(setProperty);
    } else {
      console.log('WebCC connection failed');
      updateConnectionStatus(false);
    }
  },
  // contract (see also manifest.json)
  {
    methods: {},
    events: [],
    properties: {
      URL: '',
      connect: false,
      connected: false,
      fps: 0,
      kbs: 0,
      version: false,
      token: '',
      control: false,
      play_from: '',
      play_to: '',
      play: false,
      speed: 1.0,
      live: false,
      recording_reason: '',
      recording_active: false,
      goto: '',
      timestamp: ''
    }
  },
  // placeholder to include additional Unified dependencies
  [],
  // connection timeout
  10000
);